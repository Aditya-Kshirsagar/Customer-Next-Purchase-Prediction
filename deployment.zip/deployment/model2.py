#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# In[3]:


data = pd.read_excel('Retail-Ecommerce.xlsx')


# In[4]:


# Droping Duplicated values 
data.drop_duplicates(inplace=True)


# In[5]:


data['CustomerID'].astype('object')


# In[6]:


# Quantity column has some negative values we have to remove those values as well.
# We cannot have negative values in quantity columns.
new_data = data[(data['Quantity']>0)]
new_data


# In[7]:


# Droping nUll values from data set
new_data.dropna(axis=0,inplace=True)
new_data.shape


# In[8]:


# Maximum number of customer belong to  United Kingdom.
# We wiil select United Kingdom customer only.
uk_data = new_data.query("Country == 'United Kingdom'").reset_index(drop = True)


# In[9]:


# Slipting invoice Date and Time into date.
uk_data['invoice_date'] = uk_data['InvoiceDate'].dt.date


# In[10]:


# date in year-month
uk_data['month']  =uk_data['InvoiceDate'].dt.strftime('%Y-%m')


# In[11]:


# Droping StockCode,Description,InvoiceDate and Country columns.
df = uk_data.drop(['StockCode','Description','InvoiceDate','Country'],axis=1)


# In[12]:


# Converting invoice_date column into date time format.
from datetime import datetime, timedelta,date
df['invoice_date']= pd.to_datetime(df['invoice_date'])
df['month']= pd.to_datetime(df['month'])


# In[13]:


df['Totalprice'] = df['Quantity'] * df['UnitPrice']


# In[14]:


# For prediction we need only Three columns customer ID, invoice_date and Totalprice
imp_columns = df[['CustomerID','invoice_date','Totalprice']]
df2 = imp_columns


# In[15]:


# Importing the lifetime library for getting age of customer , frequecy, Recency and monetory value
from lifetimes.utils import summary_data_from_transaction_data

# Puntting data into summary_data_from_transaction_data function.
lf_df = summary_data_from_transaction_data(df2, customer_id_col='CustomerID',
                                           datetime_col='invoice_date',monetary_value_col='Totalprice').reset_index()


# # BetaGeoFitter Model

# In[16]:


# Analazing the Frequency and Recency
# Importing Betgeofitter model.
from lifetimes import BetaGeoFitter

'''
For small samples sizes, the parameters can get implausibly large, so by adding an l2 penalty the likelihood, 
we cancontrol how large these parameters can be. 
This is implemented as setting as positive penalizer_coef in the initialization of the model. 
In typical applications, penalizers on the order of 0.001 to 0.1 are effective.

'''

bgf = BetaGeoFitter(penalizer_coef=0.1)
bgf.fit(lf_df['frequency'],lf_df['recency'],lf_df['T'])
print(bgf)


# In[17]:


#short listing customer who has atleast one purchase.
one_purchase = lf_df[lf_df['frequency']>0]


# In[18]:


from lifetimes.utils import calibration_and_holdout_data
cal_holdout = calibration_and_holdout_data(df, 'CustomerID', 'invoice_date',
                                           calibration_period_end='2011-10-30',
                                          observation_period_end= '2011-12-31',
                                          freq='D')


# # Predicting each Customer's next November months purchase count.

# In[19]:



t = 30 #days
cal_holdout['predicted_purchases'] = round(bgf.conditional_expected_number_of_purchases_up_to_time(t, cal_holdout['frequency_cal'], 
                                                                                            cal_holdout['recency_cal'],
                                                                                            cal_holdout['T_cal']),2)


# In[20]:


# Keeping those customer only which will shope atleast 1 time in noveber.

nov_customer = cal_holdout['predicted_purchases'].reset_index()


# In[21]:


# Setting values next vist of customer 1 = Yes customer visit next month and 0 = No customer won't vist. 
# Based on predicted_purchases columns values.
# Appending those vale in New column November_vist.


November_vist = []
for i in cal_holdout['predicted_purchases']:
    if i >=1:
        November_vist.append(1)
    else:
        November_vist.append(0)


# In[22]:


# Adding November_vist column to data.
# Creating copy of data under the name Nov_pred_data.

cal_holdout['November_visit'] = November_vist
Nov_pred_data = cal_holdout.reset_index()


# In[25]:


import pickle
pickle.dump(Nov_pred_data,open('model2.pkl','wb'))
model_df = pickle.load(open('model2.pkl','rb'))


# In[ ]:




