from flask import Flask,render_template,request
import pickle
import os


model = pickle.load((open('model2.pkl','rb')))


app = Flask(__name__)

uploadFolder = os.path.join('static', 'upload')
app.config['upload_image']= uploadFolder

@app.route('/')
def home():
    full_filename = os.path.join(app.config['upload_image'],'518054.jpg')
    return render_template("home.html", user_image = full_filename)



@app.route('/predict' , methods = ['POST','GET'])
def predict():
    full_filename = os.path.join(app.config['upload_image'], '518054.jpg')
    var1 =  request.form['CustomerID']
    data = model.loc[model['CustomerID'] == float(var1)]
    if  data.iat[0,7] == 1:
        visit = 'Yes'
    else:
        visit = 'No'

    return render_template('home.html',cid=var1 ,prediction_text=visit,user_image=full_filename)



if __name__ == '__main__':
    app.run(debug=True)